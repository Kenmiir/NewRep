﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        Form2 f2 = new Form2();
        Form5 f5 = new Form5();
        public static DataSet ds = new DataSet();
        public Form3()
        {
            InitializeComponent();
            //Код для выделения целой строки в элементе DataGridView
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;


        }


        private void Form3_Load(object sender, EventArgs e)
        {
            DB.LoadData() ;
            //select * from first table in BD
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Кнопка назад
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Переключение таблицы,устанавливаем текущую таблицу и индекс текущей таблицы с которой работаем
            dataGridView1.DataSource = DB.data.Tables[comboBox1.FindStringExact(comboBox1.Text)];
            DB.CurrentTable = DB.data.Tables[comboBox1.FindStringExact(comboBox1.Text)];
            DB.indexCurrentTable = comboBox1.SelectedIndex;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
         
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        { //открываем форму для редактирования по двойному клику на нужную запись и формируем ячейки с информацией о записи
            f5.Show();
            for (int i = 0; i < dataGridView1.ColumnCount; i++)
            {
                Label lb = new Label();
                lb.Text = dataGridView1.Columns[i].Name.ToString();
                lb.Location = new Point(1, 20 + 50 * i);
                f5.Controls.Add(lb);

                TextBox tb = new TextBox();
                tb.Text = dataGridView1.CurrentRow.Cells[i].Value.ToString();
                tb.Location = new Point(150, 20 + 50 * i);
                f5.Controls.Add(tb);
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
 
          
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            //открываем форму для добавления записи и формируем ячейки для записи информации
            f2.Show();
            
            for (int i = 0; i < dataGridView1.ColumnCount; i++)
            {
                Label lb = new Label();
                lb.Text = dataGridView1.Columns[i].Name.ToString();
                lb.Location = new Point(1, 20 + 50 * i);
                f2.Controls.Add(lb);

                TextBox tb = new TextBox();
                 tb.Location = new Point(150, 20 + 50 * i);
                f2.Controls.Add(tb);
            }
        }

        private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // открываем форму для редактирования и формируем ячейки с информацией о записи
            f5.Show();
            for (int i = 0; i < dataGridView1.ColumnCount; i++)
            {
                Label lb = new Label();
                lb.Text = dataGridView1.Columns[i].Name.ToString();
                lb.Location = new Point(1, 20 + 50 * i);
                f5.Controls.Add(lb);

                TextBox tb = new TextBox();
                tb.Text = dataGridView1.CurrentRow.Cells[i].Value.ToString();
                tb.Location = new Point(150, 20 + 50 * i);
                f5.Controls.Add(tb);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        { //удаление выбранной записи
            DB.deleteRow(dataGridView1.CurrentRow.Index);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //индекс текущей таблицы
            DB.CurrentRowIndex = dataGridView1.CurrentRow.Index;
        }
    }
}
