﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public void LoadData() 
            {

            }

            public Form2()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //закрытие формы
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            // проверка на незаполненные поля формы
            DataRow row = DB.CurrentTable.NewRow();
            int i = 0;
           
            foreach (TextBox tb in this.Controls.OfType<TextBox>())
            {
                if (tb.Text == null)
                {
                    MessageBox.Show("Недопустимы пустые значения!");
                    break;
                }
                else
                {
                    try
                    {
                        row[i] = tb.Text.ToString(); 
                    }
                    catch
                    {
                        MessageBox.Show("Неверный тип данных !");
                    }
                }

                i++;
            }

            DB.addRow(row);
         
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //очищение текстбоксов

            foreach (TextBox tb in this.Controls.OfType<TextBox>())
            {
                tb.Text = "";
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
