﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //сравнение старой записи с новой, введенной пользователем и сохраняет изменения
            DataRow oldRow = DB.CurrentTable.Rows[DB.CurrentRowIndex];
            List<string> values = new List<string>();
            List<string> fields = new List<string>();
            int i = 0;
            string idField = DB.CurrentTable.Columns[0].ColumnName;
            int idValue = Convert.ToInt32(DB.CurrentTable.Rows[DB.CurrentRowIndex][0]) ;
            foreach (TextBox tb in this.Controls.OfType<TextBox>())
            {
                if (tb.Text != oldRow[i].ToString())
                {
                    values.Add(tb.Text.ToString());
                    fields.Add(DB.CurrentTable.Columns[i].ColumnName);
                }
                i++;
            }
            DB.upRow(values, fields, idValue, idField);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //очищение текстбоксов
            foreach (TextBox tb in this.Controls.OfType<TextBox>())
            {
                tb.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }
    }
}
