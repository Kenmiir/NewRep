﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    { Form3 f3 = new Form3();
        Form4 f4 = new Form4();
        Form6 f6 = new Form6();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Выход из программы
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Переход на форму работы с таблицами
            f3.Show();
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Переход на форму формирования выходного документа
            f4.Show();
        }
    }
}
