﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{


    public partial class Form6 : Form
    {
        WindowsFormsApplication1.Form7 f7 = new WindowsFormsApplication1.Form7();
        public Form6()
        {
            InitializeComponent();
 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                String loginUser = LoginField.Text;
                String passUser = PasswordField.Text;

                DB db = new DB();
           
                DataTable table = new DataTable();

                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand command = new SqlCommand("SELECT * FROM `user` WHERE `UserName` = @lU AND `UserPassword`= @pU");
                command.Parameters.Add("@lU", SqlDbType.VarChar).Value = loginUser;
                command.Parameters.Add("@pU", SqlDbType.VarChar).Value = passUser;

            adapter.SelectCommand = command;
                adapter.Fill(table);
                if (table.Rows.Count > 0)
                    MessageBox.Show("Access Grant");
                else
                    MessageBox.Show("Access Denied");
            }
        }



        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            f7.Show();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }
    }
}