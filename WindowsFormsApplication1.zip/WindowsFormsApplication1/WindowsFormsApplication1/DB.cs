﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
     abstract class DB

    {
        public static DataTable CurrentTable;
        public static DataSet data = new DataSet();
        public static SqlConnection connection;
        public static SqlDataAdapter adapter;
        public static int indexCurrentTable;
        public static int CurrentRowIndex;

        public static void LoadData()
        {
            //создание подключения к базе данных
            string connect = @"Data Source=DESKTOP-1U4IQ69\SQLEXPRESS; Initial Catalog=IncidentRegistration; Integrated Security = True";
            string query = @"SELECT * FROM Crime;SELECT * FROM Suspect;SELECT * FROM Decision;";

            connection = new SqlConnection(connect);
            connection.Open(); 
            adapter = new SqlDataAdapter(query, connection);
            adapter.Fill(data);
            List<string> names = getTablesNames();
            int i = 0;
            foreach (DataTable table in data.Tables)
            {
                table.TableName = names[i];
                i++;
            }
        }
        public static void addRow(DataRow row)
        {
            //проверка на ввод пользователем уже существующего ключа
            CurrentTable.Rows.Add(row);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(adapter);
            try
            {
                adapter.Update(data, CurrentTable.TableName);
            }
            catch
            {
              
            }
            data.Clear();
            adapter.Fill(data);
        }
        public static DataTable getTable(int number)
        {
            CurrentTable = data.Tables[number];
            return data.Tables[number];
        }
        public static void deleteRow (int indexRow)
        {
            //метод удаления выбранной записи 
            DataRow row = data.Tables[indexCurrentTable].Rows[indexRow];
            string query = "DELETE FROM " + CurrentTable.TableName + " WHERE " + CurrentTable.Columns[0].ColumnName + " = " + row[0];

            SqlCommand deleteCmd = new SqlCommand(query, connection);
            adapter.DeleteCommand = deleteCmd;
            row.Delete();
            adapter.Update(data, CurrentTable.TableName);
            data.Clear();
            adapter.Fill(data, CurrentTable.TableName);
        }
        public static List<string> getTablesNames()
        {
            //сохранение названий столбцов
            List<string> names = new List<string>();
            string query = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE table_type = 'BASE TABLE'";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                names.Add(reader.GetValue(0).ToString());
            }

            reader.Close();
            return names;
        }
    
        
            public static void upRow(List<string> values, List<string> fileds, int idValue, string idFiled)
            {
            //сохранение изменений введенных пользователем в записи
               string query1 = "UPDATE " + CurrentTable.TableName + " SET ";

                string query2 = "WHERE " + idFiled + " = " + idValue;
                
            if (values.Count == 1)
            {
                if (values[0] is int)
                {
                    query1 += fileds[0] + " = " + values[0] ;
                }
                else
                {
                    query1 += fileds[0] + " = " + "'" + values[0] + "'";
                }
            }
            else
            {
                for (int i = 0; i < values.Count - 1; i++)

                {
                    if (values[i] is int) 
                    {
                        query1 += fileds[i] + " = " + values[i] + " ,";
                     
                    }
                    else
                    {
                        query1 += fileds[i] + " = " + "'" + values[i] + "' ,";
                    }
                    
                }
                query1 += fileds[values.Count-1] + " = " + "'" + values[values.Count-1] + "' ";
            }
            query1 += " " + query2;
            
            MessageBox.Show(query1);
            SqlCommand command = new SqlCommand(query1, connection);
            command.ExecuteNonQuery();
            connection.Close();
             data.Clear();
             adapter.Fill(data); 
        }
        
    }
}   
