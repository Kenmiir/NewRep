﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace WindowsFormsApplication1
{
    public partial class Form4 : Form
    {
        public static List<string> values = new List<string>();
        public static List<List<string>> rows = new List<List<string>>();
        private readonly string TemplateFileName = @"D:\Практическая Работа\Отчетный документ.docx";
        public Form4()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            foreach (TextBox tb in this.Controls.OfType<TextBox>())
            {
                values.Add(tb.Text);
            }
            rows.Add(values);

        }
         private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void Form4_Load(object sender, EventArgs e)
        {

        }

     /*   private void button3_Click(object sender, EventArgs e)
        {

            //Word app
            var wordApp = new Word.Application();
            wordApp.Visible = false;

            var wordDocument = wordApp.Documents.Open(TemplateFileName);
            ReplaceWordStub("{checkmate}", checkMate, wordDocument);
            ReplaceWordStub("{datestart}", dataStart.ToString(), wordDocument);
            ReplaceWordStub("{number}", number , wordDocument);
            ReplaceWordStub("{name}", name, wordDocument);
            ReplaceWordStub("{product}", product, wordDocument);
            ReplaceWordStub("{quantity}", quantity, wordDocument);
            ReplaceWordStub("{explanation}", explanation, wordDocument);

            wordDocument.SaveAs(@"D:\Практическая Работа\Отчетный документ готовый.docx");
            wordApp.Visible = true;

          
        }  

            private void ReplaceWordStub(string stubToReplace, string text, Word.Document wordDocument)
            {
                var range = wordDocument.Content;
               range.Find.ClearFormatting();
               range.Find.Execute(FindText: stubToReplace, ReplaceWith: text);
              
            }  */
    }
}
